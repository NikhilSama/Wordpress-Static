Credits For This Icon Set Go To:

Icontexto Inside Icons at: http://www.iconspedia.com/pack/icontexto-inside-2222/
