<?php

return array(
	'web_application_icons' => __('Web Application Icons', 'vantage'),
	'currency_icons' => __('Currency Icons', 'vantage'),
	'text_editor_icons' => __('Text Editor Icons', 'vantage'),
	'directional_icons' => __('Directional Icons', 'vantage'),
	'video_player_icons' => __('Video Player Icons', 'vantage'),
	'brand_icons' => __('Brand Icons', 'vantage'),
	'medical_icons' => __('Medical Icons', 'vantage'),
);