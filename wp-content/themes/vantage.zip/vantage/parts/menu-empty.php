<?php
/**
 * Part Name: Empty Menu
 */
?>
<nav role="navigation" class="site-navigation main-navigation primary">
	<div class="full-container">
	</div>
</nav><!-- .site-navigation .main-navigation -->