<!--This part is added by Pavan Solapure - www.opencodez.com -->	
<div id="optionsframework-metabox" class="metabox-holder" style="float:right">	
		<div id="paypal_buy">
		<h2><a href="http://demo.opencodez.com/openstrap/" target="_blank">Official Theme Demo</a></h2>
		</div>
		
		<div id="paypal_buy"><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
		<h2>Donate</h2>
		<div class="pp-field-group">		
			<select name="os0">
			<option value="Donate -">Donate - $2.00 USD</option>
			</select> 		
		</div>
		<div class="pp-field-group"><input type="hidden" name="currency_code" value="USD" /><input type="image" alt="PayPal - The safer, easier way to pay online!" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_paynowCC_LG.gif" /><img alt="" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1" border="0" /></div>
		<input type="hidden" name="cmd" value="_s-xclick">
		<input type="hidden" name="hosted_button_id" value="T4JA77YJN2H2N">
		<input type="hidden" name="on0" value="Donate" />

		</div>
		
		<div id="paypal_buy"><form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_blank">
		<h2>Buy Customization</h2>
		<div class="pp-field-group">
			<select name="os0">
			<option value="1 Customizations -">1 Customizations - $12.00 USD</option>
			<option value="2 Customizations -">2 Customizations - $20.00 USD</option>
			</select>
		</div>
		<div class="pp-field-group"><input type="hidden" name="currency_code" value="USD" /><input type="image" alt="PayPal - The safer, easier way to pay online!" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynowCC_LG.gif" /><img alt="" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1" border="0" /></div><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="M4BXBEMGJERA8"><input type="hidden" name="on0" value="Buy Customization" /></form>
		<p class="small">We will refund the full amount if we are not able to fulfill your customization request.</p>
		<p class="small">After payment, send us an email with details of your customization using the form available <a href="http://www.opencodez.com/support/" title="Contact Opencodez Support" target="_blank">here</a>. Use the same Paypal email from which you made the payment else include the transaction ID.</p>
		</div>
</div>




