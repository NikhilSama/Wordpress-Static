<?php
/**
 * The main file.
 *
 * @since singlepage 1.0.0
 */

get_header();

get_template_part("content","blog-list");

get_footer();
 