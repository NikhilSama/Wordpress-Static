<?php
/**
 * The blog list template file.
 *
 * @since singlepage 1.0.0
 */

get_header(); ?>
<?php					
get_template_part("content","blog-list");
 ?>
<?php get_footer(); ?>