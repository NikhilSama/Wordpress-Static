/*
Theme Name: Honma
Author: PWT
Theme URI: http://www.pwtthemes.com/theme/honma-free-responsive-wordpress-theme
Author URI: http://www.stefanciobanu.com
Description: Honma is an attractive  free WordPress theme available business websites or blogs. This free wordpress themes also supports HTML5/CSS3 and responsive layout. Set the branding with ease with our user friendly and detailed admin options.
Version: 1.0.3
Tags: green, black, white, light, one-column, two-columns, right-sidebar, responsive-layout, custom-menu, custom-background, editor-style, featured-images, full-width-template, theme-options, threaded-comments, translation-ready
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
Text Domain: honma
*/

== Copyright ==
Honma WordPress Theme, Copyright (C) 2014 Stefan Ciobanu
Honma WordPress Theme is licensed under the GPL 3.

Honma is built with the following resources: 

Options Framework Theme - http://wptheming.com/options-framework-theme/
License: GNU General Public License
Copyright: wptheming, http://wptheming.com

Raleway Fonts - http://www.fontsquirrel.com/fonts/raleway
License: SIL Open Font License v1.10
Copyright: The League of Moveable Type, https://www.theleagueofmoveabletype.com/

Image (home.jpg) - http://pixabay.com/en/night-aso-kumamoto-volcano-star-452706/
License: CC0 Public Domain
Copyright: Pixabay, http://pixabay.com/en/service/terms/#download_terms

Images (arrow_gray.png, arrow_white.png, content_texture.png, four_gray_px.png, header_texture.png, logotypes_shadow.png, menu.png, overlay.png, overlay_old.png, overlay_pixel.png, separe.png, two_gray_px.png) - http://www.pwtthemes.com/
License: General Public License (GPL)
Copyright: PWT, http://www.pwtthemes.com/

Main JS  - http://www.pwtthemes.com/
License: General Public License (GPL)
Copyright: PWT, http://www.pwtthemes.com/

== Installation ==

1. Upload the `Honma` folder to the `/wp-content/themes/` directory
Activation and Use
1. Activate the Theme through the 'Themes' menu in WordPress
2. See Appearance -> Theme Options to change theme options
